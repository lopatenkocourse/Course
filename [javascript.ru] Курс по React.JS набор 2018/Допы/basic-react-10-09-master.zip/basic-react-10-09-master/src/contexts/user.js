import { createContext } from 'react'

const { Provider, Consumer } = createContext('placeholder username')

export { Provider, Consumer }
